package it.adrian.fixme.connection;

import it.adrian.fixme.model.User;

public interface UserLoginResponse {
    void taskResult(User user);
}
