package it.adrian.fixme.connection;

import it.adrian.fixme.model.TroubleCode;

public interface TroubleCodesByCategoryResponse {
    void taskResult(TroubleCode troubleCode);
}
